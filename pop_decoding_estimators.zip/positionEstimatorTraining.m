function [modelParameters] = positionEstimatorTraining(training_data)
  % Arguments:
  
  % - training_data:
  %     training_data(n,k)              (n = trial id,  k = reaching angle)
  %     training_data(n,k).trialId      unique number of the trial
  %     training_data(n,k).spikes(i,t)  (i = neuron id, t = time)
  %     training_data(n,k).handPos(d,t) (d = dimension [1-3], t = time)
%   [train0,test0] = split_test_train(training_data,80);
  train0 = training_data;
    train1 = bin_and_sqrt(train0,1,true);
    train_rates = get_firing_rates(train1, 1, 40); % Assuming a Gaussian model?
    % test_rates = get_firing_rate_rect(test1, 1, 40);
    train_v = find_velocity(train_rates);
  % ... train your model
  ntrial = size(train0,1);
nangle = size(train0,2);
nneuron = 98;
%Matrices to store data
rates = [];
speeds = [];
angles = [];
%Append matrices, concatenate all firing rates after 300ms in all trials for each neuron
for n = 1:nneuron
    speed = [];
    rate = [];
    angle = [];
    for i = 1:ntrial
        for j = 1:nangle
            rate = [rate, train_v(i,j).rates(n,301:end)];
            speed = [speed, train_v(i,j).speed(301:end)];
            angle = [angle, train_v(i,j).angle(301:end)];
        end
    end
    speeds = [speeds; speed];
    rates = [rates; rate];
    angles = [angles; angle];
end

ang_gap = 5; % in degree, the resolution of the tuning curve
angs = linspace(-pi,pi,360/ang_gap+1); %Define intervals of angles to be averaged
locs_a = cell(360/ang_gap,1); % Cell array to store indices where are the elements of the raw 'angles' array within each angle intervals, only 1D because the trajectory is the same for all neurons
tuning_angs = zeros(1,360/ang_gap); % Array to store mean angles of each angle interval 
tuning_rates_ang = zeros(360/ang_gap,nneuron); %Array to store mean firing rates of each neuron in each angle intervals
tuning_errs_a = zeros(360/ang_gap,nneuron); %Array to store std of firing rates of each neuron in each angle intervals
% Record the locations/indices of the elements within the different angle intervals and calculate the mean angle for each angle interval
for a = 1:360/ang_gap
    loc = find((angles(1,:) >= angs(a)) & (angles(1,:) < angs(a+1)));
    locs_a{a} = loc;
    tuning_angs(a) = mean(angles(1,loc)); % On a second thought maybe this should be calculated using vectors but maybe fine as angle intervals are small
end
% Calculate mean and std firing rates for all neurons at all angles
for n = 1:nneuron
    for a = 1:360/ang_gap
        tuning_rates_ang(a,n) = mean(rates(n,locs_a{a}));
        tuning_errs_a(a,n) = std(rates(n,locs_a{a}));
    end
end

for n = 1:nneuron
    %     color = ones(1,3)*0.25+rand(1,3)*0.75;
    %     errorbar(tuning_angs, tuning_rates(:,n), tuning_errs(:,n))
    tuning_rates_ang(180/ang_gap+1,n) = mean(tuning_rates_ang(180/ang_gap-1:180/ang_gap+3,n));
    
end

%% movement speed tuning curve
%Similar to angle, just replacing the angle and tuning_rates_ang with speed related variables
speed_int = linspace(0,max(speed),50+1);
locs_s = cell(50,1);
tuning_speeds = zeros(1,50);
tuning_rates_s = zeros(50,nneuron);
tuning_errs_s = zeros(50,nneuron);
for s = 1:50
    loc = find((speeds(1,:) >= speed_int(s)) & (speeds(1,:) < speed_int(s+1)));
    locs_s{s} = loc;
    tuning_speeds(s) = mean(speeds(1,loc));
end
for n = 1:nneuron
    for s = 1:50
        tuning_rates_s(s,n) = mean(rates(n,locs_s{s}));
        tuning_errs_s(s,n) = std(rates(n,locs_s{s}));
    end
end

%% extract info
step_size = mean(speed); % Not sure how to predict speed best yet, so just using mean atm (INACCURATE as shown later)
usefuls = []; %Array to store neurons that show enough variability in firing rate
%Arrays to store weights, atm all weights = 1, _p, _t denote peak and trough firing rate
weights_p = []; 
weights_t = [];
% Arrays to store angles at which the neuron has max/min firing rates
peak_a = [];
trough_a = [];
% Arrays to store neurons' max/min firing rates
peak_f = [];
trough_f = [];
%Array to store std of neurons' firing rates
stds = [];
for n = 1:nneuron
    %Calculate the range and range relative to the std for each neuron
    range = max(tuning_rates_ang(:,n)) - min(tuning_rates_ang(:,n));
    zrange = max(zscore(tuning_rates_ang(:,n))) - min(zscore(tuning_rates_ang(:,n)));
    %Use arbitrary threshold to select eneurons that has enough variations, in future may use alternative criteria
    if range >= 3 && zrange >= 1 % && std(tuning_rates_ang(:,n)) >= 3
        %Find the max/min firing rates and their corresponding angle (can be found by using this ang_p/_t index in the tuning_angs array)
        [freq_p,ang_p] = max(tuning_rates_ang(:,n));
        [freq_t,ang_t] = min(tuning_rates_ang(:,n));
        % Check if these angles have already been recorded in the recording array, as we use equal weights, multiple presence of certain angles can drift the population decoding result towards that
        % angle and introduce a bias
        exist_p = find(peak_a == tuning_angs(ang_p));
        exist_t = find(trough_a == tuning_angs(ang_t));
        if length(usefuls) == 0 %If nothing has been recorded, just record whatever is found
            peak_a = [peak_a, tuning_angs(ang_p)];
            peak_f = [peak_f, freq_p];
            trough_a = [trough_a, tuning_angs(ang_t)];
            trough_f = [trough_f, freq_t];
            usefuls = [usefuls, n];
            weights_p = [weights_p, 1];
            weights_t = [weights_t, 1];
            stds = [stds, std(tuning_rates_ang(:,n))];
        elseif sum(exist_p) == 0 && sum(exist_t) == 0 %If this neuron has both peak and trough that are never recorded then record this neuron
            peak_a = [peak_a, tuning_angs(ang_p)];
            peak_f = [peak_f, freq_p];
            trough_a = [trough_a, tuning_angs(ang_t)];
            trough_f = [trough_f, freq_t];
            usefuls = [usefuls, n];
            weights_p = [weights_p, 1];
            weights_t = [weights_t, 1];
            stds = [stds, std(tuning_rates_ang(:,n))];
            % There may be a better way to include more neurons without introducing bias but probably needs to tune weights
        end
    end
end
  % Return Value:
 
  % - modelParameters:
  modelParameters = struct;
  modelParameters.peak_a = peak_a;
  modelParameters.peak_f = peak_f;
  modelParameters.trough_a = trough_a;
  modelParameters.trough_f = trough_f;
  modelParameters.usefuls = usefuls;
  modelParameters.weights_p = weights_p;
  modelParameters.weights_t = weights_t;
  modelParameters.stds = stds;
  modelParameters.step_size = step_size;
  %     single structure containing all the learned parameters of your
  %     model and which can be used by the "positionEstimator" function.
  
end