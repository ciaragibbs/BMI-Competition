function [x, y] = positionEstimator(test_data, modelParameters)

  % **********************************************************
  %
  % You can also use the following function header to keep your state
  % from the last iteration
  %
  % function [x, y, newModelParameters] = positionEstimator(test_data, modelParameters)
  %                 ^^^^^^^^^^^^^^^^^^
  % Please note that this is optional. You can still use the old function
  % declaration without returning new model parameters. 
  %
  % *********************************************************
   peak_a = modelParameters.peak_a ;
  peak_f = modelParameters.peak_f ;
  trough_a = modelParameters.trough_a;
   trough_f = modelParameters.trough_f ;
  usefuls = modelParameters.usefuls ;
   weights_p = modelParameters.weights_p ;
   weights_t = modelParameters.weights_t ;
   stds = modelParameters.stds ;
   step_size = modelParameters.step_size;
  % - test_data:
  %     test_data(m).trialID
  %         unique trial ID
  %     test_data(m).startHandPos
  %         2x1 vector giving the [x y] position of the hand at the start
  %         of the trial
  %     test_data(m).decodedHandPos
  %         [2xN] vector giving the hand position estimated by your
  %         algorithm during the previous iterations. In this case, N is 
  %         the number of times your function has been called previously on
  %         the same data sequence.
  %     test_data(m).spikes(i,t) (m = trial id, i = neuron id, t = time)
  %     in this case, t goes from 1 to the current time in steps of 20
  %     Example:
  %         Iteration 1 (t = 320):
  %             test_data.trialID = 1;
  %             test_data.startHandPos = [0; 0]
  %             test_data.decodedHandPos = []
  %             test_data.spikes = 98x320 matrix of spiking activity
  %         Iteration 2 (t = 340):
  %             test_data.trialID = 1;
  %             test_data.startHandPos = [0; 0]
  %             test_data.decodedHandPos = [2.3; 1.5]
  %             test_data.spikes = 98x340 matrix of spiking activity
%   test2 = bin_and_sqrt(test_data,1,true);
    exam = get_firing_rates_testing(test_data, 1, 40);
  
  
  % ... compute position at the given timestep.
  
    trace1 = exam.rates(:,301:end); %Get firing rates for all neurons. Start after 300ms as not much happens before stimulus given
    traceu = trace1(usefuls,:); %Select the firing rates of the variable enough neurons identified in training
    n_use = length(usefuls);%Get number of neurons for loop
    d0 = exam.startHandPos; % initial position vector
    d = [d0]; %Array for trajectory
    for t = 1:size(traceu,2)-1% time steps
        dirs = []; %Array to store direction vectors for each neuron used
        for n = 1:n_use% Loop through neurons
            if traceu(n,t) >= (peak_f(n)-stds(n) ) %If firing rate close to peak then use the angle corresponding to the peak for direction
                dirs = [dirs, weights_p(n)*[cos(peak_a(n));sin(peak_a(n))]]; %Convert angle into unit vector in 2D
            elseif traceu(n,t) <= trough_f(n)+stds(n) %If firing rate close to trough then use the angle corresponding to the trough for direction
                dirs = [dirs, weights_t(n)*[cos(trough_a(n));sin(trough_a(n))]];
            end
        end
        dir = sum(dirs,2); % Vector sum
        dir = dir/norm(dir); %Normalise to unit vector
        if length(dir) ~= 0 % In case no neuron was active/inactive enough assume no movements, otherwise increment the trajectory with the mean vector
            d0 = d0 + step_size*(dir);
        end
        d = [d, d0]; %Update the trajectory
    end
  
  % Return Value:
  x = d(1,end);
  y = d(2,end);
  % - [x, y]:
  %     current position of the hand
   
end

